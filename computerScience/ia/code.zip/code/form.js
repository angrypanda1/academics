function postToGoogle() {
  var field1 = $("#name").val();
  var field2 = $("#email").val();
  var field3 = $("#summary").val();
  var field4 = $("#phone").val();
  var field5 = $("#category option:selected").text();
  var field6 = $("#age option:selected").text();

  if(field1 == ""){
    alert('Please provide your name.');
    document.getElementById("name").focus();
    
  }
  if(field2 == ""){
    alert('Please provide your email.');
    document.getElementById("email").focus();
	  
  }
  if(field3 == "" || field3.length < 2 ){
    alert('Please provide a more detailed summary.');
    document.getElementById("email").focus();
	  
  }
  if(field4 == "" || field4.length > 12 || field4.length < 12){
    alert('Please provide your phone number.');
    document.getElementById("phone").focus();
    
  }
  if(field5 == ""){
    alert('Please provide your category.');
    document.getElementById("category").focus();
	  
  }
  if(field6 == ""){
    alert('Please provide your age.');
    document.getElementById("age").focus();
	  
  }

  $.ajax({
    url: "https://docs.google.com/forms/d/e/1FAIpQLScGBFSBWTIKNoDzHfoJApQzCPbwHJcSLxBPgvkAXbHugeqBBQ/formResponse?",
    data: {"entry.1084862479": field1, "entry.2141364104": field2, "entry.1493511292": field3, "entry.973299103": field4, "entry.1296106793": field5, "entry.1807843353": field6},
    type: "POST",
    dataType: "xml",
});

}
