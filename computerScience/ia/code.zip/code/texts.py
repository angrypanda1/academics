# Download the helper library from https://www.twilio.com/docs/python/install
import os
import time
from twilio.rest import Client
from datetime import datetime as datetime_
from datetime import timedelta
from sheets import makeDictionary

account_sid ='ACcd5262f0c01336d3f22e5a5b54f72e2a'
auth_token = 'cde623bc05f7a79dc522a9a203de3528'
client = Client(account_sid, auth_token)
phone = '+17692082613'


def currentTime():
    n = datetime_.now()
    p = n + timedelta(minutes=10)
    now = p.strftime("%H:%M")
    return now


# Your Account Sid and Auth Token from twilio.com/console
# and set the environment variables. See http://twil.io/secure

client = Client(account_sid, auth_token)
numbers = makeDictionary()

texts = ["You have 10 minutes until your performance. Please proceed to the stage.", "You have five minutes left until your performance."]

counter = 0

while True:
    performanceTime = list(numbers.values())[counter][0]
    if currentTime() != performanceTime: 
        print("Waiting for 60 seconds to check again.")
        time.sleep(60)
        continue
    else: 
        message = client.messages \
                        .create(
                            body = texts[0],
                            from_ = phone,
                            to = list(numbers.values())[counter][-1]
                        )
        print("Reminder 1 sent!") 
        time.sleep(300)
        message2 = client.messages \
                        .create(
                            body = texts[1],
                            from_ = phone,
                            to = list(numbers.values())[counter][-1]
                        )
        print("Reminder 2 sent!")
        counter += 1
        if counter == len(numbers) - 1:
            print("All notifications sent. Did you enjoy the show? ")
            break